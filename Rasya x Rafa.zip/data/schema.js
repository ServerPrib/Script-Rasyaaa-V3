module.exports = (rafatharcode, m) => {
   try {
      //━━━━━━━━━━━━━━━[ CONST ]━━━━━━━━━━━━━━━━━//
  let botNumber = rafatharcode.decodeJid(rafatharcode.user.id);
      let isNumber = (x) => typeof x === "number" && !isNaN(x);
      let user = global.db.data.users[m.sender];
      if (typeof user !== "object") global.db.data.users[m.sender] = {};
      if (user) {
              if (!("name" in user)) user.name = m.pushName
              if (!("registered" in user)) user.registered = false
              if (!("sewa" in user)) user.sewa = false
              if (!isNumber(user.freelimit)) user.freelimit = 0
        if (!user.registered) {
          if (!("name" in user)) 
          user.name = m.pushname;
          if (!isNumber(user.age))
            user.age = -1
          if (!isNumber(user.regTime))
            user.regTime = -1
        }
          if (!('unreg' in user))
          user.unreg = false
              if (!('proses_beli' in user)) user.proses_beli = false
              if (!('code_product' in user)) user.code_product = ''
              if (!('produk' in user)) user.produk = ''
              if (!('dest' in user)) user.dest = ''
              if (!('idtrx' in user)) user.idtrx = ''
              if (!('pembelian' in user)) user.pembelian = false
              if (!isNumber(user.limit)) user.limit = 0
              if (!isNumber(user.saldo)) user.saldo = 0
              if (!isNumber(user.money)) user.money = 0
               if (!isNumber(user.lastclaim)) user.lastclaim = 0
               if (!isNumber(user.lastclaim)) user.lastclaim = 0;
               if (!user.premium) user.premium = false
               if (!user.premium) user.premiumTime = 0
               if (!('orderkuota_deposit' in user)) user.orderkuota_deposit = false
               if (!('status_deposit' in user)) user.status_deposit = false
               if (!isNumber(user.orderkuota_deposit_amount)) user.orderkuota_deposit_amount = 0
         
         
         if (!("delete" in user))
            user.delete = {
               type: "",
               text: "",
               url: "",
            };
      } else
         global.db.data.users[m.sender] = {
            name: m.pushName,
            premium: false,
            registered: false,
            sewa: false,
            freelimit: 0,
            age: -1,
            regTime: -1,
            unreg: false,
            saldo: 0,
            limit: 0,
            money: 0,
            premiumTime: 0,
            lastclaim: 0,
            lastclaim: 0,
            pembelian: false,
            status_deposit: false,
            produk: '', 
            code_product: '',
            dest: '',
            idtrx: '',
            orderkuota_deposit: false,
            deposit: 0,
            orderkuota_deposit_amount: 0,
           
            
            
            
            
      
                    
            delete: {
               type: "",
               text: "",
               url: "",
            },
         };

      let setting = global.db.data.settings[botNumber];
      if (typeof setting !== "object") global.db.data.settings[botNumber] = {};
      if (setting) {
         if (!isNumber(setting.status)) setting.status = 0;
         if (!("antiviewonce" in setting)) setting.antiviewonce = true;
         if (!("autobio" in setting)) setting.autobio = true;
         if (!('autoblockcmd' in setting)) setting.autoblockcmd = false
          if (!('autodownload' in setting)) setting.autodownload = false 
         if (!("autosw" in setting)) setting.autosw = true;
         if (!("public" in setting)) setting.public = true;
         if (!('spotifyPlay' in setting)) setting.spotifyPlay = {}
      } else
         global.db.data.settings[botNumber] = {
            status: 0,
            antiviewonce: true,
            autoblockcmd: false,
            autodownload: false,
            autobio: true,
            autosw: true,
            public: true,
            spotifyPlay: {},
         };
   } catch (err) {
      console.error(err);
   }
};
